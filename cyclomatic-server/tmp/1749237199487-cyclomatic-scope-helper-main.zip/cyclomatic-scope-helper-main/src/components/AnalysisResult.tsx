import React from "react";
import { Card, Row, Col, Typography } from "antd";

const { Title } = Typography;

const AnalysisResult = ({
  cyclomaticComplexity,
  nestingDepth,
  duplicateLines,
  linesOfCode,
  averageLineLength,
  selectedMetrics,
}) => {
  const metrics = {
    cyclomaticComplexity: {
      title: "Cyclomatic Complexity",
      value: cyclomaticComplexity,
      description: "Paths through the code",
    },
    nestingDepth: {
      title: "Nesting Depth",
      value: nestingDepth,
      description: "Maximum level of nesting",
    },
    duplicateLines: {
      title: "Duplicate Lines",
      value: duplicateLines,
      description: "Repeated code lines",
    },
    linesOfCode: {
      title: "Lines of Code",
      value: linesOfCode,
      description: "Total non-empty lines",
    },
    averageLineLength: {
      title: "Average Line Length",
      value: averageLineLength,
      description: "Characters per line",
    },
  };

  return (
    <div className="space-y-6">
      <Title level={2}>Результаты анализа</Title>
      <Row gutter={[16, 16]}>
        {selectedMetrics.map((metric) => (
          <Col span={8} key={metric}>
            <Card
              title={metrics[metric].title}
              bordered={false}
              style={{ textAlign: "center" }}
            >
              <div>
                <h3>{metrics[metric].value}</h3>
                <p>{metrics[metric].description}</p>
              </div>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default AnalysisResult;
