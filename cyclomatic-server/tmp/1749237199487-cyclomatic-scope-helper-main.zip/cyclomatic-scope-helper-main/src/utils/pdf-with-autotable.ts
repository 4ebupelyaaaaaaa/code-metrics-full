/* eslint-disable @typescript-eslint/no-explicit-any */
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

(autoTable as any)(jsPDF); // вручную регистрируем плагин

export default jsPDF;
