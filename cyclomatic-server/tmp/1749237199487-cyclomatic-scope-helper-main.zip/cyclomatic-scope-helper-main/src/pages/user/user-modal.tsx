import React from "react";
import { Modal, Typography, Space, Avatar, Tooltip, Row } from "antd";
import {
  UserOutlined,
  DownloadOutlined,
  RightOutlined,
} from "@ant-design/icons";
import TagOutline from "@/UI/tag-outline";
import CustomTable from "@/UI/table/custom-table";
import type { ColumnsType } from "antd/es/table";
import "./user-modal.css";

const { Title, Text } = Typography;

interface RequestHistoryItem {
  date: string;
  filename: string;
  pdfLink: string;
}

interface UserProfileModalProps {
  visible: boolean;
  onClose: () => void;
}

const mockUser = {
  username: "IvanPetrov",
  history: [
    {
      date: "2025-04-10",
      filename: "example-code.js",
      pdfLink: "/pdfs/example-code-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "app.tsx",
      pdfLink: "/pdfs/app-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "server.ts",
      pdfLink: "/pdfs/server-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "component.tsx",
      pdfLink: "/pdfs/component-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "component.tsx",
      pdfLink: "/pdfs/component-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "component.tsx",
      pdfLink: "/pdfs/component-report.pdf",
    },
    {
      date: "2025-04-08",
      filename: "component.tsx",
      pdfLink: "/pdfs/component-report.pdf",
    },
  ],
};

const columns: ColumnsType<RequestHistoryItem> = [
  {
    key: "filename",
    dataIndex: "filename",
    render: (text) => (
      <Space direction="vertical" size={4}>
        <Title level={5} className="user-modal-filename">
          <RightOutlined className="user-modal-filename-icon" />
          {text}
        </Title>
      </Space>
    ),
  },
  {
    key: "date",
    dataIndex: "date",
    render: (date) => <Text className="user-modal-date">{date}</Text>,
  },
  {
    key: "download",
    align: "right",
    width: 60,
    render: (_, record) => (
      <Tooltip title="Скачать отчет">
        <a
          href={record.pdfLink}
          target="_blank"
          rel="noopener noreferrer"
          className="user-modal-download-link"
        >
          <DownloadOutlined />
        </a>
      </Tooltip>
    ),
  },
];

const UserProfileModal: React.FC<UserProfileModalProps> = ({
  visible,
  onClose,
}) => {
  return (
    <Modal
      open={visible}
      onCancel={onClose}
      footer={null}
      centered
      width={600}
      className="user-modal"
    >
      <Space direction="vertical" size={16} style={{ width: "100%" }}>
        <Row
          align="middle"
          justify="space-between"
          className="user-modal-header"
        >
          <Space align="center">
            <Avatar size={48} icon={<UserOutlined />} />
            <Text strong className="user-modal-username">
              {mockUser.username}
            </Text>
          </Space>
          <Title level={2} className="user-modal-title">
            <TagOutline>Личный кабинет</TagOutline>
          </Title>
        </Row>

        <div>
          <Title level={3} className="user-modal-history-title">
            История запросов
          </Title>
          <CustomTable
            dataSource={mockUser.history}
            columns={columns}
            pagination={false}
            showHeader={false}
            rowKey="filename"
          />
        </div>
      </Space>
    </Modal>
  );
};

export default UserProfileModal;
