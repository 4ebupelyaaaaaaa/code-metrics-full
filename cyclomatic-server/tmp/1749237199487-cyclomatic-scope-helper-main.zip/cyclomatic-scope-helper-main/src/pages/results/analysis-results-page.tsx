/* eslint-disable @typescript-eslint/no-explicit-any */
import { useLocation } from "react-router-dom";
import { AnalysisResult } from "@/types/analyze";
import { useEffect, useState } from "react";
import { Card, Row, Col, Table, Typography } from "antd";
import { Pie } from "@ant-design/plots"; // или другой график по нужде

const ResultsPage = () => {
  const location = useLocation();
  const { analysis, selectedReports } = location.state as {
    analysis: AnalysisResult;
    selectedReports: string[];
  };

  const [cards, setCards] = useState<any[]>([]);
  const [tables, setTables] = useState<any[]>([]);
  const [charts, setCharts] = useState<any[]>([]);

  useEffect(() => {
    const newCards = [];
    const newTables = [];
    const newCharts = [];

    if (selectedReports.includes("Среднее значение сложности по проекту")) {
      newCards.push({
        name: "Средняя цикломатическая сложность",
        value: analysis.cyclomaticComplexity,
      });
    }

    if (
      selectedReports.includes("Максимальная глубина вложенности по функциям")
    ) {
      newCards.push({
        name: "Максимальная глубина вложенности",
        value: analysis.nestingDepth,
      });
    }

    if (selectedReports.includes("Количество строк, которые дублируются")) {
      newCards.push({
        name: "Количество дублированных строк",
        value: analysis.duplicateLines,
      });
    }

    if (
      selectedReports.includes(
        "Процент дублирования по отношению к общему количеству строк"
      )
    ) {
      newCards.push({
        name: "Процент дублирования",
        value: `${analysis.duplicatePercentage}%`,
      });
    }

    if (
      selectedReports.includes("Функции, сложность которых превышает порог")
    ) {
      newTables.push({
        name: "Функции с высокой сложностью",
        columns: [
          { title: "Имя", dataIndex: "name", key: "name" },
          {
            title: "Сложность",
            dataIndex: "cyclomaticComplexity",
            key: "cc",
          },
        ],
        dataSource: analysis.highComplexityFunctions || [],
      });
    }

    if (selectedReports.includes("Список мест, где найдено дублирование")) {
      newTables.push({
        name: "Фрагменты дублированного кода",
        columns: [
          { title: "Файл", dataIndex: "file", key: "file" },
          { title: "Начало", dataIndex: "startLine", key: "startLine" },
          { title: "Конец", dataIndex: "endLine", key: "endLine" },
        ],
        dataSource: analysis.duplicationLocations || [],
      });
    }

    if (
      selectedReports.includes(
        "Список функций с превышением допустимой глубины"
      )
    ) {
      newTables.push({
        name: "Функции с глубокой вложенностью",
        columns: [
          { title: "Имя", dataIndex: "name", key: "name" },
          { title: "Глубина", dataIndex: "nestingDepth", key: "depth" },
        ],
        dataSource: analysis.topNestedFunctions || [],
      });
    }

    if (selectedReports.includes("Список найденных ошибок")) {
      newTables.push({
        name: "Список ошибок",
        columns: [
          { title: "Тип", dataIndex: "type", key: "type" },
          { title: "Сообщение", dataIndex: "message", key: "message" },
          { title: "Файл", dataIndex: "file", key: "file" },
          { title: "Строка", dataIndex: "line", key: "line" },
        ],
        dataSource: analysis.errors || [],
      });
    }

    if (selectedReports.includes("Количество ошибок по типу")) {
      newTables.push({
        name: "Ошибки по типам",
        columns: [
          { title: "Тип ошибки", dataIndex: "type", key: "type" },
          { title: "Количество", dataIndex: "count", key: "count" },
        ],
        dataSource: analysis.errors || [],
      });
    }

    if (selectedReports.includes("Распределение сложности")) {
      newCharts.push({
        name: "Распределение сложности",
        data: Object.entries(analysis.complexityDistribution || {}).map(
          ([category, value]) => ({
            category,
            value,
          })
        ),
      });
    }

    if (selectedReports.includes("Распределение вложенности")) {
      newCharts.push({
        name: "Распределение вложенности",
        data: Object.entries(analysis.averageFunctionNesting || {}).map(
          ([category, value]) => ({
            category,
            value,
          })
        ),
      });
    }

    setCards(newCards);
    setTables(newTables);
    setCharts(newCharts);
  }, [analysis, selectedReports]);

  return (
    <div style={{ padding: 24 }}>
      <Row gutter={[16, 16]}>
        {cards.map((card) => (
          <Col span={6} key={card.name}>
            <Card>
              <Typography.Title level={5}>{card.name}</Typography.Title>
              <Typography.Text>{card.value}</Typography.Text>
            </Card>
          </Col>
        ))}
      </Row>

      {tables.map((table) => (
        <div key={table.name} style={{ marginTop: 24 }}>
          <Typography.Title level={4}>{table.name}</Typography.Title>
          <Table
            columns={table.columns}
            dataSource={table.dataSource}
            pagination={false}
            rowKey="name"
          />
        </div>
      ))}

      {charts.map((chart) => (
        <div key={chart.name} style={{ marginTop: 24 }}>
          <Typography.Title level={4}>{chart.name}</Typography.Title>
          <Pie
            data={chart.data}
            angleField="value"
            colorField="category"
            radius={0.9}
            label={{
              type: "outer",
              content: "{name} {percentage}",
            }}
            interactions={[{ type: "element-active" }]}
          />
        </div>
      ))}
    </div>
  );
};

export default ResultsPage;
