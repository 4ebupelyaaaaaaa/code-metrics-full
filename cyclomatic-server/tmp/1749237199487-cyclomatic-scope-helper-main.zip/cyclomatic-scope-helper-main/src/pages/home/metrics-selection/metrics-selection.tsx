/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { Button, Card, Col, Row, Typography, Upload, message } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import TagOutline from "@/UI/tag-outline";
import jsPDF from "jspdf";
import { RcFile } from "antd/es/upload";
import { analyzeCode } from "@/services/analyzer/codeAnalyzer";
import { generatePDF } from "@/services/report/pdfGenerator";
import { useNavigate } from "react-router-dom";

const { Title } = Typography;

const MetricsSelectionCard: React.FC = () => {
  const navigate = useNavigate();

  const [selectedMetric, setSelectedMetric] = useState<string>(
    "Цикломатическая сложность"
  );
  const [selectedReports, setSelectedReports] = useState<string[]>([]);

  const handleFile = async (file: RcFile) => {
    try {
      const text = await file.text();
      const result = analyzeCode(text);

      navigate("/results", {
        state: { analysis: result, selectedReports },
      });

      message.success("Файл успешно проанализирован.");
    } catch (error) {
      console.error("Ошибка анализа файла:", error);
      message.error("Ошибка при анализе файла");
    }

    return false;
  };

  const reportOptions: Record<string, string[]> = {
    "Цикломатическая сложность": [
      "Среднее значение сложности по проекту",
      "Функции, сложность которых превышает порог",
      "Распределение сложности",
    ],
    "Глубина вложенности": [
      "Максимальная глубина вложенности по функциям",
      "Список функций с превышением допустимой глубины",
      "Распределение вложенности",
    ],
    "Дублирование кода": [
      "Количество строк, которые дублируются",
      "Список мест, где найдено дублирование",
      "Процент дублирования по отношению к общему количеству строк",
    ],
    "Статический анализ": [
      "Список найденных ошибок",
      "Количество ошибок по типу",
    ],
  };

  const toggleReport = (report: string) => {
    setSelectedReports((prev) =>
      prev.includes(report)
        ? prev.filter((r) => r !== report)
        : [...prev, report]
    );
  };

  return (
    <Row justify="center">
      <Col xs={24} xl={30} xxl={18}>
        <Card className="custom-border">
          <Row gutter={[24, 24]} align="stretch">
            <Col xs={24} md={12}>
              <Card className="transparent" style={{ flex: 1 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-start",
                    marginBottom: 16,
                  }}
                >
                  <TagOutline color="dark">Выбор метрик</TagOutline>
                </div>

                {Object.keys(reportOptions).map((metric) => (
                  <Button
                    key={metric}
                    className={`metric-btn ${
                      selectedMetric === metric ? "active" : ""
                    }`}
                    type="default"
                    onClick={() => {
                      setSelectedMetric(metric);
                    }}
                  >
                    {metric}
                  </Button>
                ))}
              </Card>
            </Col>

            <Col xs={24} md={12}>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 16,
                  height: "100%",
                }}
              >
                <div style={{ width: "100%" }}>
                  <Upload
                    beforeUpload={handleFile}
                    showUploadList={false}
                    accept=".js,.ts,.tsx"
                  >
                    <Button
                      icon={<UploadOutlined />}
                      type="primary"
                      block
                      style={{ width: "100%" }}
                    >
                      Загрузить код
                    </Button>
                  </Upload>
                </div>

                <Card className="transparent" style={{ flex: 1 }}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                      marginBottom: 16,
                    }}
                  >
                    <TagOutline color="light">Содержание отчета</TagOutline>
                  </div>

                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 16,
                    }}
                  >
                    {reportOptions[selectedMetric].map((report) => (
                      <Button
                        key={report}
                        type="primary"
                        block
                        className={
                          selectedReports.includes(report) ? "active" : ""
                        }
                        onClick={() => toggleReport(report)}
                      >
                        {report}
                      </Button>
                    ))}
                  </div>
                </Card>
              </div>
            </Col>
          </Row>
        </Card>
      </Col>
    </Row>
  );
};

export default MetricsSelectionCard;
