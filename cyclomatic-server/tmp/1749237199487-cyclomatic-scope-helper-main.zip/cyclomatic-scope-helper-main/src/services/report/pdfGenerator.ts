import jsPDF from "jspdf";
import { AnalysisResult } from "@/types/analyze";

import "@/../public/fonts/Roboto-Regular-normal.js";

export const generatePDF = (
  analysis: AnalysisResult,
  selectedReports: string[]
) => {
  const doc = new jsPDF();

  if (!selectedReports.length) {
    throw new Error("Нет выбранных отчетов для генерации PDF.");
  }

  // 👇 установка шрифта после импорта
  doc.setFont("Roboto-Regular", "normal");

  doc.setFontSize(18);
  doc.text("Отчет об анализе кода", 20, 20);
  doc.setFontSize(12);

  let y = 30;
  const lineHeight = 10;

  const addSectionTitle = (title: string) => {
    doc.setFontSize(14);
    doc.setFont("Roboto-Regular", "normal");
    doc.text(title, 20, y);
    y += lineHeight;
    doc.setFontSize(12);
    doc.setFont("Roboto-Regular", "normal");
  };

  const addText = (label: string, value: string | number) => {
    doc.text(`${label}: ${value}`, 25, y);
    y += lineHeight;
  };

  const addList = (items: string[]) => {
    items.forEach((item) => {
      doc.text(`- ${item}`, 30, y);
      y += lineHeight;
    });
  };

  selectedReports.forEach((report) => {
    addSectionTitle(report);

    switch (report) {
      case "Среднее значение сложности по проекту":
        addText(
          "Средняя цикломатическая сложность",
          analysis.cyclomaticComplexity ?? "Нет данных"
        );
        break;

      case "Функции, сложность которых превышает порог":
        if (analysis.highComplexityFunctions?.length) {
          analysis.highComplexityFunctions.forEach((func) => {
            addText(`${func.name}`, `Сложность: ${func.cyclomaticComplexity}`);
          });
        } else {
          addText("Функций с высокой сложностью не найдено", "");
        }
        break;

      case "Распределение сложности":
        if (analysis.complexityDistribution) {
          Object.entries(analysis.complexityDistribution).forEach(
            ([range, count]) => {
              addText(`${range}`, `${count} функций`);
            }
          );
        } else {
          addText("Распределение сложности пока не доступно", "");
        }
        break;

      case "Максимальная глубина вложенности по функциям":
        addText(
          "Максимальная глубина вложенности",
          analysis.nestingDepth ?? "Нет данных"
        );
        break;

      case "Список функций с превышением допустимой глубины":
        if (analysis.topNestedFunctions?.length) {
          analysis.topNestedFunctions.forEach((func) => {
            addText(`${func.name}`, `Глубина: ${func.nestingDepth}`);
          });
        } else {
          addText("Функций с высокой вложенностью не найдено", "");
        }
        break;

      case "Количество строк, которые дублируются":
        addText(
          "Количество дублирующихся строк",
          analysis.duplicateLines ?? "Нет данных"
        );
        break;

      case "Список мест, где найдено дублирование":
        if (analysis.duplicationLocations?.length) {
          addList(
            analysis.duplicationLocations.map(
              (loc) => `Файл: ${loc.file}, Строки: ${loc.lines.join(", ")}`
            )
          );
        } else {
          addText("Дублирования не найдено", "");
        }
        break;

      case "Процент дублирования по отношению к общему количеству строк":
        addText(
          "Процент дублирования",
          `${analysis.duplicatePercentage?.toFixed(2) ?? 0}%`
        );
        break;

      case "Список найденных ошибок":
        if (analysis.errors?.length) {
          addList(
            analysis.errors.map(
              (error) =>
                `Функция: ${error.functionName}, Ошибка: ${error.message}`
            )
          );
        } else {
          addText("Ошибок не найдено", "");
        }
        break;

      case "Количество ошибок по типу":
        if (analysis.errorStats) {
          Object.entries(analysis.errorStats).forEach(([errorType, count]) => {
            addText(`${errorType}`, `${count} ошибок`);
          });
        } else {
          addText("Статистика по ошибкам недоступна", "");
        }
        break;

      default:
        addText("Данных для этой метрики пока нет", "");
        break;
    }

    y += lineHeight;

    if (y > 270) {
      doc.addPage();
      y = 20;
    }
  });

  doc.save("code-analysis.pdf");
};
