import { FunctionAnalysis, FilterOptions } from "../../types/analyze";

export function filterFunctions(
  functions: FunctionAnalysis[],
  options: FilterOptions
): FunctionAnalysis[] {
  return functions.filter((func) => {
    const nestingOk = options.minNestingDepth
      ? func.nestingDepth >= options.minNestingDepth
      : true;
    const complexityOk = options.minCyclomaticComplexity
      ? func.cyclomaticComplexity >= options.minCyclomaticComplexity
      : true;
    return nestingOk && complexityOk;
  });
}
