export function calculateDuplicatePercentage(lines: string[]): number {
  const lineMap = new Map<string, number>();
  let duplicateLines = 0;

  lines.forEach((line) => {
    const normalizedLine = line.trim().replace(/\s+/g, " ");
    if (!normalizedLine) return;
    const count = lineMap.get(normalizedLine) || 0;
    lineMap.set(normalizedLine, count + 1);
    if (count > 0) {
      duplicateLines++;
    }
  });

  return (duplicateLines / lines.length) * 100;
}
