import { FunctionAnalysis } from "../../types/analyze";
import { complexityKeywords } from "../../constants/metrics";

// Анализ одной функции
export function analyzeFunction(
  functionBlock: string,
  functionName: string
): FunctionAnalysis {
  const lines = functionBlock.split("\n");
  let cyclomaticComplexity = 1;
  let currentNestingDepth = 0;
  let maxNestingDepth = 0;

  complexityKeywords.forEach((keyword) => {
    const regex = new RegExp(`\\b${keyword}\\b`, "g");
    const matches = functionBlock.match(regex);
    if (matches) {
      cyclomaticComplexity += matches.length;
    }
  });

  lines.forEach((line) => {
    const codeLine = line.replace(/".*?"/g, "").replace(/'.*?'/g, "");
    const open = (codeLine.match(/{/g) || []).length;
    const close = (codeLine.match(/}/g) || []).length;
    currentNestingDepth += open - close;
    if (currentNestingDepth > maxNestingDepth) {
      maxNestingDepth = currentNestingDepth;
    }
  });

  const argsMatch = functionBlock.match(/\(([^)]*)\)/);
  const argumentsCount = argsMatch
    ? argsMatch[1].split(",").filter((arg) => arg.trim().length > 0).length
    : 0;

  return {
    name: functionName,
    cyclomaticComplexity,
    nestingDepth: maxNestingDepth,
    argumentsCount,
    linesOfCode: lines.length,
  };
}
