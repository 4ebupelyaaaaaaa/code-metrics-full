import { complexityKeywords } from "../../constants/metrics";
import { analyzeFunction } from "./functionUtils";
import { calculateDuplicatePercentage } from "./duplicationUtils";
import { FunctionAnalysis, AnalysisResult } from "../../types/analyze";

export function analyzeCode(code: string): AnalysisResult {
  const lines = code.split("\n").filter((line) => line.trim().length > 0);
  let cyclomaticComplexity = 1;
  let totalLineLength = 0;
  let maxNestingDepth = 0;
  let currentNestingDepth = 0;

  lines.forEach((line) => {
    const trimmed = line.trim();
    if (trimmed.length === 0) return;

    totalLineLength += trimmed.length;

    const codeLine = line.replace(/".*?"/g, "").replace(/'.*?'/g, "");

    complexityKeywords.forEach((keyword) => {
      const regex = new RegExp(`\\b${keyword}\\b`, "g");
      const matches = codeLine.match(regex);
      if (matches) {
        cyclomaticComplexity += matches.length;
      }
    });

    const open = (codeLine.match(/{/g) || []).length;
    const close = (codeLine.match(/}/g) || []).length;
    currentNestingDepth += open - close;
    maxNestingDepth = Math.max(maxNestingDepth, currentNestingDepth);
  });

  // Анализ функций
  const functionAnalyses: FunctionAnalysis[] = [];
  const functionRegex = /function\s+([a-zA-Z0-9_]+)\s*\([^)]*\)\s*{/g;
  let match: RegExpExecArray | null;

  while ((match = functionRegex.exec(code)) !== null) {
    const functionName = match[1];
    const startIndex = code.indexOf("{", match.index);
    if (startIndex === -1) continue;

    let openBraces = 1;
    let currentIndex = startIndex + 1;
    while (openBraces > 0 && currentIndex < code.length) {
      const char = code[currentIndex];
      if (char === "{") openBraces++;
      else if (char === "}") openBraces--;
      currentIndex++;
    }
    const functionBlock = code.substring(match.index, currentIndex);
    const analysis = analyzeFunction(functionBlock, functionName);
    functionAnalyses.push(analysis);
  }

  const topNestedFunctions = functionAnalyses
    .slice()
    .sort((a, b) => b.nestingDepth - a.nestingDepth)
    .slice(0, 4);

  const highComplexityFunctions = functionAnalyses
    .filter((func) => func.cyclomaticComplexity > 10)
    .sort((a, b) => b.cyclomaticComplexity - a.cyclomaticComplexity);

  const duplicatePercentage = calculateDuplicatePercentage(lines);

  const totalArguments = functionAnalyses.reduce(
    (acc, func) => acc + func.argumentsCount,
    0
  );
  const maxFunctionLength = functionAnalyses.reduce(
    (max, func) => Math.max(max, func.linesOfCode),
    0
  );
  const averageFunctionNesting =
    functionAnalyses.reduce((acc, func) => acc + func.nestingDepth, 0) /
    (functionAnalyses.length || 1);

  return {
    cyclomaticComplexity,
    nestingDepth: maxNestingDepth,
    duplicateLines: Math.round((duplicatePercentage / 100) * lines.length),
    linesOfCode: lines.length,
    averageLineLength: Math.round(totalLineLength / lines.length),
    topNestedFunctions,
    highComplexityFunctions,
    duplicatePercentage,
    averageArgumentsPerFunction:
      functionAnalyses.length > 0
        ? totalArguments / functionAnalyses.length
        : 0,
    maxFunctionLength,
    averageFunctionNesting,
  };
}
