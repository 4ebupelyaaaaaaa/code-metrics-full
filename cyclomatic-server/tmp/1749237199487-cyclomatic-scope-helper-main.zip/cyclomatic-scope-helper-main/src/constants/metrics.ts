// Ключевые слова для расчёта цикломатической сложности
export const complexityKeywords = [
  "if",
  "else if",
  "while",
  "for",
  "case",
  "&&",
  "\\|\\|",
  "\\?",
  "catch",
];

// Ключевые слова для расчёта вложенности
export const nestingKeywords = [
  "{",
  "if",
  "for",
  "while",
  "switch",
  "try",
  "function",
  "class",
];
